﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FIT5032_Week03.HelloWorld
{
    public class Hello
    {
        public String GetHello()
        {
            return "Hello World";
        }
    }
}